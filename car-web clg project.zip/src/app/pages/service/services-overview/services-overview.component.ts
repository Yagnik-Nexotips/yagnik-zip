import { Component } from '@angular/core';

@Component({
  selector: 'app-services-overview',
  standalone: true,
  imports: [],
  templateUrl: './services-overview.component.html',
  styleUrl: './services-overview.component.scss'
})
export class ServicesOverviewComponent {

}
