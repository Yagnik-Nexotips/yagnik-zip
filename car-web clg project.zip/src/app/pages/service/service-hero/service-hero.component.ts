import { Component } from '@angular/core';

@Component({
  selector: 'app-service-hero',
  standalone: true,
  imports: [],
  templateUrl: './service-hero.component.html',
  styleUrl: './service-hero.component.scss'
})
export class ServiceHeroComponent {

}
