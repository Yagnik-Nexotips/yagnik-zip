import { Component } from '@angular/core';

@Component({
  selector: 'app-latest-models',
  standalone: true,
  imports: [],
  templateUrl: './latest-models.component.html',
  styleUrl: './latest-models.component.scss'
})
export class LatestModelsComponent {

}
