import { Component } from '@angular/core';

@Component({
  selector: 'app-filter-search-section',
  standalone: true,
  imports: [],
  templateUrl: './filter-search-section.component.html',
  styleUrl: './filter-search-section.component.scss'
})
export class FilterSearchSectionComponent {

}
