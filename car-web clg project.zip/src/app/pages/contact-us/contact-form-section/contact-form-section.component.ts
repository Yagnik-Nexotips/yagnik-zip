import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-form-section',
  standalone: true,
  imports: [],
  templateUrl: './contact-form-section.component.html',
  styleUrl: './contact-form-section.component.scss'
})
export class ContactFormSectionComponent {

}
