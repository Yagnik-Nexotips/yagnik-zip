import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-us-hero',
  standalone: true,
  imports: [],
  templateUrl: './contact-us-hero.component.html',
  styleUrl: './contact-us-hero.component.scss'
})
export class ContactUsHeroComponent {

}
