import { Component } from '@angular/core';

@Component({
  selector: 'app-about-hero',
  standalone: true,
  imports: [],
  templateUrl: './about-hero.component.html',
  styleUrl: './about-hero.component.scss',
})
export class AboutHeroComponent {}
