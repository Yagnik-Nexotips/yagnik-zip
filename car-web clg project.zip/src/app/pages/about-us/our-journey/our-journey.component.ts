import { Component } from '@angular/core';

@Component({
  selector: 'app-our-journey',
  standalone: true,
  imports: [],
  templateUrl: './our-journey.component.html',
  styleUrl: './our-journey.component.scss'
})
export class OurJourneyComponent {

}
