import { Component } from '@angular/core';

@Component({
  selector: 'app-our-mission',
  standalone: true,
  imports: [],
  templateUrl: './our-mission.component.html',
  styleUrl: './our-mission.component.scss'
})
export class OurMissionComponent {

}
